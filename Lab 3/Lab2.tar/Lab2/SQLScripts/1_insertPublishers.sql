INSERT INTO Publisher VALUES
(10000, 'Wiley'),
(10001, 'McGraw-Hill'),
(10002, 'Coyote Publishing'),
(10003, 'Amazon'),
(10004, 'Jerrys Ice Cream'),
(10005, 'Buy a Boat'),
(10006, 'Flagstaff Publishing'),
(10007, 'Ram West');